# Tipos de variáveis: 

    # Inteiro(int)

age = 27

    # Ponto flutuante ou decimal (float)

miopia = 2.5

    # String (str)

nome = "Matheus"

    # Boolean (bool)

solteiro = False  

# Solicitação de dados do usuário:

n=input("Por favor, digite o seu nome: ")
print(f"Bem-vindo ao nosso programa, {n}! ")